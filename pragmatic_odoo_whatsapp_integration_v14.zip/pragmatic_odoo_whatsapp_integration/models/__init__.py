from . import res_config_settings
from . import res_partner
from . import project_task
from . import crm_lead
from . import account_invoice
from . import res_users
